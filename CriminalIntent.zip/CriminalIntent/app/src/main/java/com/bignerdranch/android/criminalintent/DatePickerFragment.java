package com.bignerdranch.android.criminalintent;

import androidx.fragment.app.DialogFragment;

public class DatePickerFragment extends DialogFragment {
}
