package com.bignerdranch.android.criminalintent;

import androidx.fragment.app.Fragment;

public class CrimeListFragment extends Fragment {
}
